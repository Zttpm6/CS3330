/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zttpm6finalproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Zach Taylor
 */
public class AboutController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    /**
     *
     * @param event
     * @throws IOException
     */
    @FXML
    public void updateMonitor(ActionEvent event) throws IOException{
        
        //System.out.println("Going to page 2.");
        //System.out.println("page2scene is null");
                
        Parent page2Parent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene page2Scene = new Scene(page2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(page2Scene);
        window.show();
    }
}
