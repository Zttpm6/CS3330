/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zttpm6finalproject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author Zach Taylor
 */
public class FXMLDocumentController implements Initializable {
    
    private Stage stage;
    private Scene page1Scene;

    
    @FXML
    private Label OrderNum;
    @FXML
    private Button order1;
    @FXML
    private Button order2;
    @FXML
    private Button order3;
    @FXML
    private Button order4;
    @FXML
    private Button update;
    @FXML
    private Label label;
    @FXML
    private Label Food1;
    @FXML
    private Label Food2;
    @FXML
    private Label Food3;
    @FXML
    private Label Food4;
    @FXML
    private Label FullOrder;

    
    private int counter;
    OrderClass orderBuffer = new OrderClass();
    EntreeFood entree = new EntreeFood();
    DrinksClass drink = new DrinksClass();
    DessertFood dessert = new DessertFood();
    ArrayList <String> Buffer = new ArrayList <>(4);
    private int orderCount = 0;
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        entree.readFile();
        Food1.setText(entree.records.get(0));
        Food2.setText(entree.records.get(1));
        Food3.setText(entree.records.get(2));
        Food4.setText(entree.records.get(3));
    }
    public void start(Stage stage) {
        System.out.println("Page 1 has started");
        this.stage = stage; 
        this.page1Scene = stage.getScene();
    }

    @FXML
    public void aboutMonitor(ActionEvent event) throws IOException{
        
        //System.out.println("Going to page about.");
        //System.out.println("page2scene is null");
                
        Parent page2Parent = FXMLLoader.load(getClass().getResource("About.fxml"));
        Scene page2Scene = new Scene(page2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(page2Scene);
        window.show();
    }
    @FXML
    public void updateMonitor(ActionEvent event) throws IOException{
        
        //System.out.println("Going to page 2.");
        //System.out.println("page2scene is null");
                
        Parent page2Parent = FXMLLoader.load(getClass().getResource("Page2.fxml"));
        Scene page2Scene = new Scene(page2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(page2Scene);
        window.show();
    }

        
    @FXML
    public void updateOrder1(ActionEvent event){
    //System.out.println("HIT IT BABY");
    //System.out.println(counter);
    counter = counter + 1;
    if(counter ==1)
    {
        drink.readFile();
        Food1.setText(drink.records.get(0));
        Food2.setText(drink.records.get(1));
        Food3.setText(drink.records.get(2));
        Food4.setText(drink.records.get(3));
        orderBuffer.order.add(entree.records.get(0));
    }
    if(counter == 2)
    {
        dessert.readFile();
        Food1.setText(dessert.records.get(0));
        Food2.setText(dessert.records.get(1));
        Food3.setText(dessert.records.get(2));
        Food4.setText(dessert.records.get(3));
        orderBuffer.order.add(drink.records.get(0));
    }
    if(counter == 3)
    {
        entree.readFile();
        Food1.setText(entree.records.get(0));
        Food2.setText(entree.records.get(1));
        Food3.setText(entree.records.get(2));
        Food4.setText(entree.records.get(3));
        orderBuffer.order.add(dessert.records.get(0));
        counter = 0;
        Buffer = orderBuffer.getOrder();
       FullOrder.setText(Buffer.get(0)+ " " + Buffer.get(1) + " " + Buffer.get(2));
        orderCount = orderCount +1;
        OrderNum.setText("Your number is " + orderCount);
    }
    }
       @FXML
    public void updateOrder2(ActionEvent event){
    //System.out.println("HIT IT BABY");
    //System.out.println(counter);
    counter = counter + 1;
    if(counter ==1)
    {
        drink.readFile();
        Food1.setText(drink.records.get(0));
        Food2.setText(drink.records.get(1));
        Food3.setText(drink.records.get(2));
        Food4.setText(drink.records.get(3));
        orderBuffer.order.add(entree.records.get(1));
    }
    if(counter == 2)
    {
        dessert.readFile();
        Food1.setText(dessert.records.get(0));
        Food2.setText(dessert.records.get(1));
        Food3.setText(dessert.records.get(2));
        Food4.setText(dessert.records.get(3));
        orderBuffer.order.add(drink.records.get(1));
    }
    if(counter == 3)
    {
        entree.readFile();
        Food1.setText(entree.records.get(0));
        Food2.setText(entree.records.get(1));
        Food3.setText(entree.records.get(2));
        Food4.setText(entree.records.get(3));
        orderBuffer.order.add(dessert.records.get(1));
        counter = 0;
        Buffer = orderBuffer.getOrder();
        FullOrder.setText(Buffer.get(0)+ " " + Buffer.get(1) + " " + Buffer.get(2));
        Buffer.clear();
        orderCount = orderCount +1;
        OrderNum.setText("Your number is " + orderCount);
    }
    }
       @FXML
    public void updateOrder3(ActionEvent event){
    //System.out.println("HIT IT BABY");
    //System.out.println(counter);
    counter = counter + 1;
    if(counter ==1)
    {
        drink.readFile();
        Food1.setText(drink.records.get(0));
        Food2.setText(drink.records.get(1));
        Food3.setText(drink.records.get(2));
        Food4.setText(drink.records.get(3));
        orderBuffer.order.add(entree.records.get(2));
    }
    if(counter == 2)
    {
        dessert.readFile();
        Food1.setText(dessert.records.get(0));
        Food2.setText(dessert.records.get(1));
        Food3.setText(dessert.records.get(2));
        Food4.setText(dessert.records.get(3));
        orderBuffer.order.add(drink.records.get(2));
    }
    if(counter == 3)
    {
        entree.readFile();
        Food1.setText(entree.records.get(0));
        Food2.setText(entree.records.get(1));
        Food3.setText(entree.records.get(2));
        Food4.setText(entree.records.get(3));
        orderBuffer.order.add(dessert.records.get(2));
        counter = 0;
        Buffer = orderBuffer.getOrder();
        FullOrder.setText(Buffer.get(0)+ " " + Buffer.get(1) + " " + Buffer.get(2));
        Buffer.clear();
        orderCount = orderCount +1;
        OrderNum.setText("Your number is " + orderCount);
    }
    }
    @FXML
    public void updateOrder4(ActionEvent event){
    //System.out.println("HIT IT BABY");
    //System.out.println(counter);
    counter = counter + 1;
    if(counter ==1)
    {
        drink.readFile();
        Food1.setText(drink.records.get(0));
        Food2.setText(drink.records.get(1));
        Food3.setText(drink.records.get(2));
        Food4.setText(drink.records.get(3));
        orderBuffer.order.add(entree.records.get(3));
    }
    if(counter == 2)
    {
        dessert.readFile();
        Food1.setText(dessert.records.get(0));
        Food2.setText(dessert.records.get(1));
        Food3.setText(dessert.records.get(2));
        Food4.setText(dessert.records.get(3));
        orderBuffer.order.add(drink.records.get(3));
    }
    if(counter == 3)
    {
        entree.readFile();
        Food1.setText(entree.records.get(0));
        Food2.setText(entree.records.get(1));
        Food3.setText(entree.records.get(2));
        Food4.setText(entree.records.get(3));
        orderBuffer.order.add(dessert.records.get(3));
        counter = 0;
        Buffer = orderBuffer.getOrder();
        FullOrder.setText(Buffer.get(0)+ "     " + Buffer.get(1) + "    " + Buffer.get(2));
        Buffer.clear();
        orderCount = orderCount +1;
        OrderNum.setText("Your number is " + orderCount);
    }
    }
}