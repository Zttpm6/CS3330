/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zttpm6finalproject;

import java.util.ArrayList;

/**
 *
 * @author Zach Taylor
 */
abstract class Food {
    public int cost;
    public ArrayList<String> records;

    Food() {
        this.records = new ArrayList<>(4);
    }
    abstract void updateFile(String addFood);
    abstract void readFile(); 
}
