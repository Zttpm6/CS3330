/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zttpm6finalproject;

import java.util.ArrayList;

/**
 *
 * @author Zach Taylor
 */
public class OrderClass {
    public ArrayList<String> order;
    
    public OrderClass() {
        this.order = new ArrayList<>(4);
    }
    public void updateOrder(String food){
       order.add(food);
    }
    public ArrayList<String> getOrder(){
        return order;
    }
}
