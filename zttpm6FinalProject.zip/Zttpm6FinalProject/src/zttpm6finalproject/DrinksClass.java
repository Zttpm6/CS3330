/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zttpm6finalproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Zach Taylor
 */
public class DrinksClass extends Food{

    @Override
    void updateFile(String addFood) {
                records.remove(3);
        records.add(addFood);
        
        try{
        File file = new File("Drinks.txt");
        FileWriter fw = new FileWriter(file);
            try (BufferedWriter bw = new BufferedWriter(fw)) {
                for(String str: records){
                    bw.write(str + "\n");
                    
                }
            }
        }
        catch(IOException e){
            System.out.println("Error writing the BufferedWriter");
        }
        
    }

    @Override
    @SuppressWarnings("ConvertToTryWithResources")
    void readFile() {
        try
        {
            BufferedReader reader = new BufferedReader(new FileReader("Drinks.txt"));
            String line;
            while((line = reader.readLine())!= null)
            {
                records.add(line);
            }
            reader.close();
        }
        catch(IOException e)
        {
            System.err.format("Exception occured trying to read Lunch.txt");
        }
    }
    
}
