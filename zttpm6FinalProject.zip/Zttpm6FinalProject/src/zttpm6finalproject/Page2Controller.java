/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zttpm6finalproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Zach Taylor
 */
public class Page2Controller implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Label Food1;
    @FXML
    private Label Food2;
    @FXML
    private Label Food3;
    @FXML
    private TextField Food4;
    
    EntreeFood entree = new EntreeFood();
    DrinksClass drink = new DrinksClass();
    DessertFood dessert = new DessertFood();
    int choice = 0;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
      public void updateMonitor(ActionEvent event) throws IOException{
        
        //System.out.println("Going to page 2.");
        //System.out.println("page2scene is null");
                
        Parent page2Parent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene page2Scene = new Scene(page2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(page2Scene);
        window.show();
    }
    
    @FXML
    public void updateOrder1(ActionEvent event){ 
        entree.readFile();
        Food1.setText(entree.records.get(0));
        Food2.setText(entree.records.get(1));
        Food3.setText(entree.records.get(2)); 
        Food4.setText(entree.records.get(3));
        choice = 1;
    }
    @FXML
    public void updateDrinks(ActionEvent event){ 
        drink.readFile();
        Food1.setText(drink.records.get(0));
        Food2.setText(drink.records.get(1));
        Food3.setText(drink.records.get(2)); 
        Food4.setText(drink.records.get(3));
        choice = 2;
    }
    @FXML
    public void updateDessert(ActionEvent event){ 
        dessert.readFile();
        Food1.setText(dessert.records.get(0));
        Food2.setText(dessert.records.get(1));
        Food3.setText(dessert.records.get(2)); 
        Food4.setText(dessert.records.get(3));
        choice = 3;
    }
    @FXML
    public void updateFiles(ActionEvent event){
        if(choice == 1){
            entree.updateFile(Food4.getText());
        }
        if(choice == 2){
            drink.updateFile(Food4.getText());
        }
        if(choice == 3){
            dessert.updateFile(Food4.getText());
        }
        else{
           
        }
    }
}
